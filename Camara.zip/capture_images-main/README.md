# Capturador de Imagenes
La forma en que Android delega acciones a otras aplicaciones es mediante la invocación de un Intent que describe lo que deseas que se haga. Este proceso tiene tres partes: el Intent en sí, una llamada para iniciar la Activity externa y un poco de código para manejar los datos de la imagen cuando el foco vuelve a tu actividad



Este ejemplo ha sido creado para los vídeos de YouTube:
- [Deprecated startActivityForResult](https://www.youtube.com/watch?v=DSn8IVMvRJ0 "Deprecated startActivityForResult")
- [Captura de imagenes Android Kotlin](https://www.youtube.com/watch?v=Srp6e5LK8WI "Captura de imagenes Android Kotlin")
- [Guardar imágenes en la gelería Android Kotlin](https://www.youtube.com/watch?v=pSKFbToSHGM "Guardar imágenes en la gelería Android Kotlin")



